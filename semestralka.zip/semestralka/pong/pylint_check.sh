file=$1

pylint $file --disable=C0301,C0103
