"""init file to make the directory into a module"""
from .application import Application
