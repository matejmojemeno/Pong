file=$1

autopep8 --in-place --aggressive --aggressive $file
